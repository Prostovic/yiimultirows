﻿DROP DATABASE IF EXISTS multirowtest;
CREATE DATABASE multirowtest;
GRANT ALL PRIVILEGES ON multirowtest.* TO 'multirowtest'@'%' IDENTIFIED BY '111222' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON multirowtest.* TO 'multirowtest'@'localhost' IDENTIFIED BY '111222' WITH GRANT OPTION;

Use multirowtest;

DROP TABLE IF EXISTS `multirowtest_main`;
CREATE TABLE `multirowtest_main` (
	`id` int NOT NULL AUTO_INCREMENT,
	`name` varchar(32),
	`value` varchar(32),
	PRIMARY KEY (`id`),
	KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SHOW WARNINGS;
 

DROP TABLE IF EXISTS `multirowtest_slave`;
CREATE TABLE `multirowtest_slave` (
	`id` int NOT NULL AUTO_INCREMENT,
	`param` varchar(32),
	`selected` tinyint,
	`type` tinyint,
	`created` datetime,
	`main_id` int Not Null,
	PRIMARY KEY (`id`),
	KEY `main_id` (`main_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SHOW WARNINGS;
 
DROP TABLE IF EXISTS `multirowtest_addition`;
CREATE TABLE `multirowtest_addition` (
	`id` int NOT NULL AUTO_INCREMENT,
	`text` varchar(32),
	`main_id` int Not Null,
	PRIMARY KEY (`id`),
	KEY `main_id` (`main_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SHOW WARNINGS;
 