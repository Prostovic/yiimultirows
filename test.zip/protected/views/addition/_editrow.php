<?php
/* @var $this AdditionController */
/* @var $model Addition */
/* @var $form CActiveForm */
?>

<div class="additionrow">

	<div class="row">
		<?php echo $form->labelEx($model,'['.$index.']text'); ?>
		<?php echo $form->textArea($model,'['.$index.']text',array('rows'=>3)); ?>
		<?php echo $form->error($model,'['.$index.']text'); ?>
	</div>

	<div class="row">
		<a href="" class="deladditionrecord">Delete Addition</a>
	</div>

</div>