<?php
/* @var $this AdditionController */
/* @var $model Addition */

$this->breadcrumbs=array(
	'Additions'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List Addition', 'url'=>array('index')),
	array('label'=>'Create Addition', 'url'=>array('create')),
	array('label'=>'View Addition', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage Addition', 'url'=>array('admin')),
);
?>

<h1>Update Addition <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>