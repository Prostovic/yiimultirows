<?php
/* @var $this AdditionController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Additions',
);

$this->menu=array(
	array('label'=>'Create Addition', 'url'=>array('create')),
	array('label'=>'Manage Addition', 'url'=>array('admin')),
);
?>

<h1>Additions</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
