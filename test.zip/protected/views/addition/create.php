<?php
/* @var $this AdditionController */
/* @var $model Addition */

$this->breadcrumbs=array(
	'Additions'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Addition', 'url'=>array('index')),
	array('label'=>'Manage Addition', 'url'=>array('admin')),
);
?>

<h1>Create Addition</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>