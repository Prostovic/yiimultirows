<?php
/* @var $this SlaveController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Slaves',
);

$this->menu=array(
	array('label'=>'Create Slave', 'url'=>array('create')),
	array('label'=>'Manage Slave', 'url'=>array('admin')),
);
?>

<h1>Slaves</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
