<?php
/* @var $this SlaveController */
/* @var $model Slave */
/* @var $form CActiveForm */
?>

	<div class="slaverow">
		<div class="row">
			<?php echo $form->labelEx($model,'['.$index.']param'); ?>
			<?php echo $form->textField($model,'['.$index.']param',array('size'=>32,'maxlength'=>32)); ?>
			<?php echo $form->error($model,'['.$index.']param'); ?>
		</div>

		<div class="row">
			<?php echo $form->labelEx($model,'['.$index.']selected'); ?>
			<?php echo $form->checkBox($model,'['.$index.']selected'); ?>
			<?php echo $form->error($model,'['.$index.']selected'); ?>
		</div>

		<div class="row">
			<?php echo $form->labelEx($model,'['.$index.']type'); ?>
			<?php echo $form->dropDownList($model,'['.$index.']type', Slave::$aTypes); ?>
			<?php echo $form->error($model,'['.$index.']type'); ?>
		</div>

		<div class="row">
			<?php echo $form->labelEx($model,'['.$index.']created'); ?>
			<?php echo $form->textField($model,'['.$index.']created'); ?>
			<?php echo $form->error($model,'['.$index.']created'); ?>
		</div>

		<div class="row">
			<a href="" class="delslaverecord">Delete Slave</a>
		</div>
	</div>

