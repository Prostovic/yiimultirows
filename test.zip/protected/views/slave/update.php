<?php
/* @var $this SlaveController */
/* @var $model Slave */

$this->breadcrumbs=array(
	'Slaves'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List Slave', 'url'=>array('index')),
	array('label'=>'Create Slave', 'url'=>array('create')),
	array('label'=>'View Slave', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage Slave', 'url'=>array('admin')),
);
?>

<h1>Update Slave <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>