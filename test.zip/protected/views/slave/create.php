<?php
/* @var $this SlaveController */
/* @var $model Slave */

$this->breadcrumbs=array(
	'Slaves'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Slave', 'url'=>array('index')),
	array('label'=>'Manage Slave', 'url'=>array('admin')),
);
?>

<h1>Create Slave</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>