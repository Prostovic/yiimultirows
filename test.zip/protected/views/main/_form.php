<?php
/* @var $this MainController */
/* @var $model Main */
/* @var $form CActiveForm */
?>

<div class="form">

<?php

$form=$this->beginWidget('CActiveForm', array(
	'id'=>'main-form',
	'enableAjaxValidation'=>true,
	'clientOptions' => array(
		'validateOnType' => false,
		'validateOnChange' => false,
		'validateOnSubmit' => true,
	),
));

$sCss = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'css' . DIRECTORY_SEPARATOR . 'multirows.css';
Yii::app()->clientScript->registerCssFile(Yii::app()->assetManager->publish($sCss));

?>

	<p class="note">Fields with <span class="required">*</span> are required.</p>

	<?php echo $form->errorSummary($model); ?>


	<div class="screenpart">
		<div class="row">
			<?php echo $form->labelEx($model,'name'); ?>
			<?php echo $form->textField($model,'name',array('size'=>32,'maxlength'=>32)); ?>
			<?php echo $form->error($model,'name'); ?>
		</div>

		<div class="row">
			<?php echo $form->labelEx($model,'value'); ?>
			<?php echo $form->textField($model,'value',array('size'=>32,'maxlength'=>32)); ?>
			<?php echo $form->error($model,'value'); ?>
		</div>

		<div class="row buttons">
			<?php echo CHtml::submitButton($model->isNewRecord ? 'Create' : 'Save'); ?>
		</div>
	</div>

	<div class="screenpart">
		<h1>Slave records <a href="" id="addslaverecord">Add new Slave</a></h1>

<?php
$this->Widget(
	'ext.multiroute.MultirowsWidget',
	array(
		'model'   => 'Slave',
		'records' => $model->slave,
		'form' => $form,
		'rowview' => '//slave/_editrow',
		'addlinkselector' => '#addslaverecord',
		'dellinkselector' => '.delslaverecord',
		'formselector' => '#main-form',
	)
);
?>

		<div class="clearfix"></div>
	</div>

	<div class="screenpart">
		<h1>Addition records <a href="" id="addadditionrecord">Add new Addition</a></h1>

<?php
$this->Widget(
	'ext.multiroute.MultirowsWidget',
	array(
		'model'   => 'Addition',
		'records' => $model->addition,
		'form' => $form,
		'rowview' => '//addition/_editrow',
		'addlinkselector' => '#addadditionrecord',
		'dellinkselector' => '.deladditionrecord',
		'formselector' => '#main-form',
	)
);
?>

		<div class="clearfix"></div>
	</div>
<?php $this->endWidget(); ?>

</div><!-- form -->